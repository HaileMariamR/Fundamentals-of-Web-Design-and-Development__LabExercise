//Load Every thing ....
document.addEventListener("DOMContentLoaded", () => {
    startTime();
    loadPost();
    loadPosts();
});